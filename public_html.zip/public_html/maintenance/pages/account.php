<!DOCTYPE html>
<html lang="en">

<?php include("../../header.php") ?>

<body>
    <?php include('../../nav.php') ?>


    <div class="container mt-5">
        <h1>Create Your Account</h1>
        <p>Please fill this form to create an Account</p>
        <form action="account.php" method="POST">
            <div class="form-group">
                <label for="email">Email Id:</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Email id">
            </div><br>
            <div class="form-group">

                <label for="password">Password:</label><br>
                <input class="form-control" type="password" id="password" name="password">
            </div><br>

            <div class="form-group">
                <label for="rpassword">Repeat Password:</label>
                <input class="form-control" type="password" id="rpassword" name="rpassword">

            </div><br>
            <input class="btn btn-primary" type="submit" value="Submit">
        </form>

        <p>By filling this form, you will create a login account.</p>
        <a href="../index1.html">maintenance Page</a>

    </div>

    <?php
    $servername = "10.72.1.14";
    $username = "group2";
    $dbpass = "6QOIHm";
    $dbname = "group2";


    $conn = new mysqli($servername, $username, $dbpass, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $_POST['email'];
    $post_password = $_POST['password'];
    $post_rpassword = $_POST['rpassword'];

    if (empty($email) || empty($post_password)) {
        print "No field should be empty";
    } else if ($post_password == $post_rpassword) {
        $sql = "INSERT INTO account(email,password) VALUES ('$email','$post_password') ;";

        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

    } else {
        print "Repeated password is not the same as the password";
    }

    ?>
    
    <?php include('../../footer.php') ?>

</body>

</html>