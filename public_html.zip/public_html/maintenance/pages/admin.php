<!DOCTYPE html>
<html lang="en">

<?php include("../../header.php") ?>

<body>
    <?php include('../../nav.php') ?>


    <?php
    $servername = "10.72.1.14";
    $username = "group2";
    $dbpass = "6QOIHm";
    $dbname = "group2";


    $conn = new mysqli($servername, $username, $dbpass, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    $sql = "SELECT uid, fname FROM member";
    $result = $conn->query($sql);
    ?>

    <div class="container mt-5">
        <p>You need to fill this form to register as a Admin.</p>

        <form action="admin.php" method="POST">
            <div class="form-group">

                <label for="chooseuser">Select Member</label><br>
                <?php
                if ($result->num_rows > 0) {
                    echo '<select id="chooseuser" class="form-control" name="chooseuser">';
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value=' . $row["uid"] . '>' . $row["fname"] . '</option>';
                    }

                    echo '</select>';
                } else {
                    echo "No User Found";
                }
                ?>

            </div>

            <div class="form-group">
                <label for="permission">Select Permission</label><br>

                <select id="permission" class="form-control" name="permission">
                    <option value="Read,Edit,Delete">Read, Edit, Delete</option>
                    <option value="Read,Edit">Read,Edit</option>
                    <option value="Read">Read</option>
                </select>
            </div>
            <div class="form-group">

                <label for="payment">Choose Payment Method</label><br>
                <select id="payment" class="form-control" name="payment">
                    <option value="Cash">Cash</option>
                    <option value="Bank-Transfer">Bank Transfer</option>
                    <option value="PayPal">PayPal</option>
                </select>
            </div>
            <input class="btn btn-primary" type="submit" value="Submit">

        </form>



        <p>By filling this form, you will be registered as a Admin and Client(Default).</p>

    </div>


    <?php
    $user = $_POST['chooseuser'];
    $permission_post = $_POST['permission'];
    $payment_post = $_POST['payment'];


    if (empty($user) || empty($permission_post)) {
        print "No field should be empty";
    } else {
        $sql = "INSERT INTO admin(uid,permission_type) VALUES ($user,'$permission_post') ;
        ";
        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
            header(" Location: admin.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    
    $conn->close();
    ?>

    <?php include('../../footer.php') ?>

</body>

</html>