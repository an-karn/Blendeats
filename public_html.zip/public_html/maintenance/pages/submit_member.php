<?php
    $servername = "10.72.1.14";
    $username = "group2";
    $dbpass = "6QOIHm";
    $dbname = "group2";


    $conn = new mysqli($servername, $username, $dbpass, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $fname_post = $_POST['fname'];
    $lname_post = $_POST['lname'];
    $bio_post = $_POST['bio'];
    $profile_pic =$_POST['file'];
    $number_post = $_POST['contact'];
    $country_post = $_POST['country'];


    $bio_post = empty($bio_post) ? "NULL" : "'$bio_post'";
    $profile_pic =empty($profile_pic) ? "NULL" : "'$profile_pics'";
    $number_post = empty($number_post) ? "NULL" : "'$number_post'";



    if (empty($fname_post) || empty($lname_post) || empty($country_post)) {
        print "Name and Country are Mandatory";
    } else {
        $sql = "INSERT INTO member(fname, lname, bio, profilepic, contact , country) 
        VALUES ('$fname_post','$lname_post',$bio_post,$profile_pic, $number_post,'$country_post') ;
    ";
        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
            header(" Location: admin.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    $conn->close();
    ?>