<!DOCTYPE html>
<html lang="en">

<?php include("../../header.php") ?>

<body>
    <?php include('../../nav.php') ?>


    <div class="container mt-5">
        <h1>What are you selling ???</h1>
        <p>You need to fill this form to list your food item</p>
        <form action="food.php" method="POST">

            <div class="form-group">
                <label for="title">Title:</label>
                <input class="form-control" type="text" id="title" name="title" placeholder="Title">
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <input class="form-control" type="text" id="description" name="description" placeholder="Description">
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input class="form-control" type="number" id="price" name="price" placeholder="Price">
            </div>

            <div class="form-group">
                <label for="file">Picture:</label>
                <input class="form-control-file" type="file" name="file" id="file">
            </div>
            <input class="btn btn-primary" type="submit" value="Submit">
        </form>

        <p>By filling this form, you can sell food.</p>

    </div>


    <?php

    $servername = "10.72.1.14";
    $username = "group2";
    $dbpass = "6QOIHm";
    $dbname = "group2";


    $conn = new mysqli($servername, $username, $dbpass, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $title_post = $_POST['title'];
    $description_post = $_POST['description'];
    $image_post = $_POST['file'];
    $price_post = $_POST['price'];

    $description_post = empty($description_post) ? "NULL" : "'$description_post'";
    $image_post = empty($image_post) ? "NULL" : "'$image_post'";
    $price_post = empty($price_post) ? "NULL" : $price_post;
    
    if (empty($title_post)) {
        print "No field should be empty";
    } else {
        $sql = "INSERT INTO food(title,description,image,price) 
        VALUES ('$title_post',$description_post,$image_post,$price_post) ;";
        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
            header(" Location: admin.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    $conn->close();
    ?>

    <?php include('../../footer.php') ?>

</body>

</html>